# PRCOME 전체 디자인 통일 — HANDOFF

> 작업 폴더: `C:\Users\mycom\Desktop\PR컴_개선` (원본 `PRCOME`는 절대 수정 금지)
> 서버: 5731 (PR컴_개선) / 5730 (원본). preview_start 'prcome-improved'(5731)·'prcome'(5730)로 재기동.
> 목표: 나머지 서브페이지를 **메인·인사이트 매거진 디자인 시스템**으로 통일. 콘텐츠·링크·JS 기능은 보존.

## ★ 레퍼런스 기준 (2026-07-21 추가) — 사이트별 참고 범위 분리
> **원칙**: 세 사이트를 그대로 복제/혼합하지 말 것. 정보구조·위계·이용흐름만 재해석. 로고·브랜드색·실제 문구/콘텐츠/광고는 사용 금지. 해외 콘텐츠·해외 샘플 금지 → **국내 언론홍보·PR 업계 가상 콘텐츠**만. 공통 헤더/푸터/폰트/토큰/버튼 규칙은 전 페이지 유지(서로 다른 사이트처럼 보이면 안 됨). PC+태블릿+모바일 반응형 필수.

### 1) 로켓펀치(rocketpunch.com) → **커뮤니티 페이지 전용 레퍼런스**
- 참고: **3분할(좌 카테고리 내비 · 중앙 콘텐츠 피드 · 우 추천정보)**, 작성자 프로필↔게시물 연결, 이름·직무·소속 표기, 게시물 카드 정보 위계, 최신소식+피드 동시 구성, 사용자·기업 프로필로 이어지는 구조, **높은 정보 밀도(정돈된)**.
- 제외: 채용 플랫폼 성격, 검은 로고·명칭·실제 게시물/광고·색상·화면 복제. → **홍보담당자·언론인·PR회사 종사자가 교류하는 전문 네트워크 커뮤니티**로 변경.
- 커뮤니티 카테고리(8): 전체 피드 / 질문·답변 / 업계 소식 / 실무 노하우 / 언론홍보 사례 / 자유게시판 / 구인구직 / 홍보대행 의뢰.
- 게시물 표시요소: 작성자 프로필이미지·이름·직무(전문분야)·소속(회사/언론사)·작성시간·제목·본문·이미지/첨부·태그·공감/댓글/저장/공유·조회수·반응수.
- 우측 영역: 인기 작성자 · 추천 PR회사 · 추천 언론사 · 인기 주제 · 최신 업계 소식.

### 2) 오픈애즈(openads.co.kr) → **인사이트 매거진/콘텐츠 페이지 레퍼런스**
- 참고: 대표 콘텐츠 크게 보여주는 **히어로**, 제목·설명 위계, 최신 인사이트 카드 배열, 카테고리·콘텐츠유형 표시, 작성자/출처, **저장(북마크)** 기능, 섹션 구분선·여백, 카드 크기·중요도 차등, 실제 운영 매거진 같은 콘텐츠 밀도.
- 제외: 로고·주황 브랜드색·실제 콘텐츠/문구.
- 인사이트 카테고리(9): 언론홍보 전략 / 보도자료 작성 / 기자 커뮤니케이션 / 브랜드 PR / 위기관리 / 공공기관 홍보 / 스타트업 PR / 홍보 트렌드 / 실무 자료.

### 3) Market's Lab(marketslab.net) → **현행 공통 디자인 시스템(유지)**
- 나머지 페이지(PR회사·언론사·구인구직·홍보대행 의뢰·도서·교육기관·각 목록/상세·로그인/회원가입·기타 서비스)를 이 방향으로 통일.
- 유지요소: 넓고 정돈된 레이아웃, 절제된 색, 명확한 타이포 위계, 일정한 콘텐츠 너비(1280), 충분한 정보 밀도, 깔끔한 구분선·카드, 일관된 필터/탭/검색창/버튼, 차분한 전문 플랫폼 분위기.

### 4) 메인페이지 → **독립 플랫폼 허브**(세 사이트 중 하나를 따라하지 않음)
- 연결 콘텐츠: PRCOME 핵심소개 · 대표 인사이트 · 최신/인기 커뮤니티 · 추천 PR회사 · 추천 언론사 · 최신 채용 · 홍보대행 의뢰 · PR 도서/교육 · 가입/이용 유도. **중요도별 영역 크기·배치 차등**(동일 카드 반복 금지).

## 공통 디자인 기준 (하나의 CSS = `assets/css/magazine-system.css`)
- **로드**: Pretendard CDN + `{root}assets/css/magazine-system.css` (공통). style.css는 제거하거나(전면 재작성 시) 남겨도 magazine-system 오버라이드가 덮음. 페이지 고유 레이아웃만 페이지 내 `<style>`.
- **헤더/푸터**: `<div id="mag-header"></div>` / `<div id="mag-footer"></div>` + `<script src="{root}assets/js/magazine-header.js"></script>`. 그 앞에 `<script>window.MAG={root:'../'또는'',home:...,catBase:'{root}insights/index.html'}</script>`. **site.js·id="site-header" 금지.**
- **토큰**: bg `#FAFAF8` / surface `#FFFFFF` / 본문 `#111827` / 네이비 `#0E1B3A`(var --navy) / 보조 `#667085` / 포인트 `#315CFF`(var --pt) / 구분선 `#D9DEE7`. radius 4~8, 그림자 최소. 최대폭 1280(.wrap), 좌우 여백 24. 폰트 Pretendard.
- **페이지 상단**: `.subhead`(= crumb + h1[앞에 파란 `.tick`] + `.desc`). `.page-hero`(구형) 대신 사용 권장. (page-hero도 magazine-system이 밝게 재스킨하므로 급하지 않으면 유지 가능)
- **컴포넌트**: 버튼 min-height 44·radius 4(.btn / .mk-btn), 입력창 48, 카드=얇은 테두리+무그림자(radius 4~8), 탭=텍스트+파란 밑줄(.subtabs/.btabs), 필터바=.fbar, 목록=촘촘한 데이터 행(.plist/.dlist/.drow, 얇은 구분선), 썸네일=.mini-poster(16:10 or 4:3)·대표 .imgwrap(16:9)+.poster-g.
- **상세 레이아웃**: 기사=본문 720 narrow prose+인용/핵심박스; 회사/전문가=프로필 헤더+정보 사이드; 목록→상세 링크 유지.
- **모바일(≤900)**: topnav→햄버거+아코디언, 그리드 1열, 가로 스크롤 0.

## 헤더 IA (magazine-header.js, 언론 70:30)
9개 대분류: 홈/커뮤니티/매거진/PR도구/기업·미디어/프로젝트·매칭/교육·행사/구인구직/더보기. 매거진·도구·디렉터리 드롭다운은 **언론 우선 순서**. 카테고리 링크는 insights/index.html?cat=… (마케팅·디지털→digital, 미디어→media 등), 커뮤니티 ?cat 호환(media→industry,collab→knowhow,seo→pr-qa,?cate= 지원).

## 변환 레시피 (OLD → 공통)
1. `<link ... style.css>` 뒤에 `<link rel="stylesheet" href="{root}assets/css/magazine-system.css">` 추가
2. `id="site-header"`→`id="mag-header"`, `id="site-footer"`→`id="mag-footer"`
3. `<script>window.SITE_ROOT='{r}';</script>` → 뒤에 `window.MAG={root:'{r}',home:'{r}index.html',catBase:'{r}insights/index.html'}` 추가
4. `{r}assets/js/site.js` → `{r}assets/js/magazine-header.js`
5. (깊은 통일) `<header class="page-hero"><div class="wrap"><div class="crumb">…</div><h1>…</h1><p class="lead">…</p></div></header>` → `.subhead`(crumb+h1+tick+desc)로 교체하고 본문 카드/목록을 magazine 패턴으로 재구성.

## 전체 페이지 체크리스트 (40)
상태: [완료-full]=매거진 레이아웃 / [완료-공통]=매거진 헤더+토큰(본문 style.css) / [TODO]=옛 site.js

- index.html … [완료-full]
- insights/index.html, insights/article.html … [완료-full]
- community/index.html … [완료-full] / community/post.html, community/write.html … [완료-공통, 본문 재스킨 필요]
- directory/index.html … [완료-full] / directory/agencies.html, media.html … [완료-공통, 재스킨 필요] / directory/detail.html … [완료-공통] / directory/register.html … [TODO] / directory/expert-register.html … [완료-full]
- projects/index.html, new.html, detail.html … [완료-full] / projects/inquiry.html, portfolio.html … [완료-full]
- career/index.html, career/detail.html … [TODO]
- tools/index.html, ai-press-release.html, coverage-check.html, media-recommend.html, visibility.html … [TODO] / tools/press-release.html, distribute.html … [완료-공통, ?start 링크·엔진 유지] / tools/checklist, title-generator, pitch-mail … [완료-full]
- events/index.html, more/index.html … [완료-full]
- resources/books.html … [TODO]
- auth/login.html, signup.html, password-reset.html … [TODO]
- legal/terms.html, privacy.html … [TODO]
- help/guide.html, contact.html … [TODO]
- notice/index.html … [TODO]

## ▶ 진행 로그 (2026-07-21)
- [완료] 17개 옛 site.js 페이지 → 공통 헤더/시스템 일괄 전환(auth·career·directory/register·help·legal·notice·resources·tools/index·ai-press-release·coverage-check·media-recommend·visibility). **전 사이트 공통 헤더·푸터·토큰·버튼·카드 통일.**
- [완료-full] directory/agencies.html, directory/media.html → 매거진 목록형(subhead+fbar+dlist, 클라이언트 필터, style.css/명조/구favicon 제거)
- [남음-2차] directory/detail(상세), projects(index/new/detail), career(index/detail), tools(index/coverage-check/media-recommend/visibility/ai-press-release), community(post/write), resources/books, auth(3), legal(2), help(2), notice → **공통 헤더·토큰은 적용됨. page-hero→subhead + 목록/상세 매거진 레이아웃 재스킨은 미완(본문은 style.css 컴포넌트, 오버라이드로 색·버튼·카드만 통일됨).**
- [완료-full] projects/index.html(subhead+상단 등록버튼+텍스트밑줄 탭+데이터행 목록 .plist/.prow+필터·정렬·페이저, ?cat= 유지) · projects/new.html(subhead+매거진 폼 카드 .fcard/step/inp·sel·ta, style.css 제거) · projects/detail.html(프로필 헤더 dhead+본문 prose+정보 사이드 .side sticky+비슷한 프로젝트 카드). style.css/명조/구favicon/SITE_ROOT 전부 제거, JS 기능·링크 보존.
- 링크: 깨진 링크 0, 옛 헤더 잔여 0. 목록→detail.html 이동 정상.

## ▶ 진행 로그 (2026-07-21 · 레퍼런스 반영 세션)
- [헤더] magazine-header.js 커뮤니티 드롭다운 → 신 8분류(전체피드/질문·답변/업계소식/실무노하우/언론홍보사례/자유게시판/구인구직/홍보대행의뢰)로 교체. 구 링크(pr-qa·mkt-qa·industry·promo·intro·media·collab·seo)는 community/index.html 별칭으로 호환.
- [완료-full·로켓펀치형] community/index.html → **3분할(좌 카테고리 내비 · 중앙 피드 · 우 추천)**. 게시물 카드=프로필ava+이름+직무배지+소속+시간+제목+본문+첨부+태그+공감/댓글/저장/공유+조회. 우측=인기작성자·추천PR회사·추천언론사·인기주제·최신소식. 인기/최신 정렬. 채용플랫폼 성격 제거→PR 전문 네트워크. 국내 가상 콘텐츠.
- [완료-full] community/post.html(작성자 프로필 헤더+본문+태그+공감/저장/공유+베스트답변/댓글+우측 작성자카드·관련글), community/write.html(신 8분류 셀렉트·매거진 폼), **community/profile.html 신규**(프로필 헤더+통계+작성글/답변/저장 탭). 게시물↔작성자 프로필 상호 링크.
- [완료·오픈애즈 반영] insights/index.html → 대표 콘텐츠 히어로(기존 feature 유지)+**출처 라벨·저장(북마크) 아이콘** 추가(피처 fmeta·카드 .save). 기존 카테고리/JS 보존.
- [완료-full·Market's Lab] career/index(subhead+fbar+dlist), career/detail(프로필헤더+prose+사이드+비슷한공고), directory/detail(프로필헤더+소개/서비스/이력+사이드), directory/register·auth 3종(login/signup/password-reset)·resources/books(도서 카드+교육기관 섹션)·help/guide(카드+FAQ)·help/contact(문의 폼)·notice/index·legal/terms·legal/privacy → style.css/명조/구favicon/SITE_ROOT 제거, subhead/매거진 컴포넌트로 자립화.
- [완료·독립 허브] index.html → 최신 채용 + 홍보대행 의뢰 2열, 도서·교육 2열, 네이비 가입 CTA 밴드 추가. 실무 커뮤니티 탭 신 8분류로 갱신. 중요도별 영역 차등 유지.
- [보존] tools/*(press-release·distribute·coverage-check·media-recommend·visibility·ai-press-release·index·pr-agent) → AI 엔진·?start 파라미터 보호 위해 미변경(공통 헤더·토큰은 이미 적용됨).
- [검증] 5731 서버. 콘솔 에러 0. 내부 링크 28개 타깃 전수 200(깨진 링크 0). PC(1280)/태블릿(768)/모바일(375) 반응형 — 커뮤니티 3→2→1열, 모바일 가로 스크롤 0(커뮤니티 카테고리는 내부 가로 스크롤 칩). 전 페이지 style.css/page-hero/site.js 잔여 0(tools 제외).

## ▶ 진행 로그 (2026-07-21 · marketslab 구조 차용 · 1단계)
> 방향(사용자 확정): **PRCOME 정체성 유지 + marketslab.net 구조/레이아웃 차용**, **핵심부터 단계적**. 커뮤니티는 로켓펀치 3분할 유지.
- [헤더 IA 재편] magazine-header.js → **marketslab형 10대분류**: 홈/커뮤니티/마케팅도구/콘텐츠/체험단/매칭/마케팅몰(NEW)/구인구직/공지사항/더보기. 드롭다운 HOT·NEW 배지, **상단 유틸바(날짜·오늘 방문·로그인/가입)** 추가. PRCOME 콘텐츠 매핑(매칭→directory+projects, 콘텐츠→insights). magazine-system.css에 .util·.bdg 추가.
- [홈 리빌드] index.html → **마케팅랩형**: 히어로(헤드라인+무료진단+통계 294/11.2K/2,354+LIVE), 오늘의 활동(출석·행운·랭킹·견적)+이번 주 활동왕, 마케팅 도구 그리드, 주간 인기글+최신글, 게시판 4종(자유/마케팅정보/기자단/구인구직), 가이드 3, 파트너사, 가입 CTA.
- [마케팅도구] tools/index.html(전체 도구=마케팅+PR 그룹) 재작성. **신규 계산기(실동작)**: insta-calculator(참여율), cost-calculator(CPC·CPM·ROAS), hashtag-generator(복사), keyword-analyzer·rate-card(단가표)·blog-index(지수 진단)·keyword-trend(12개월 추이) — 모두 클라이언트 JS 동작. 기존 PR AI 도구(press-release·distribute·pr-agent 등) 보존.
- [체험단 신규] experience/index.html(체험단·기자단 통합 모집 피드, 유형 탭·카드), experience/register.html(모집 등록 폼).
- [커뮤니티 정렬] 카테고리를 marketslab형으로: 전체피드/가입인사(NEW)/자유게시판/질의사항/홍보게시판/마케팅정보/기자단 모집/구인구직. **로켓펀치 3분할 레이아웃 유지**, 구 링크(qa·knowhow·case 등) 별칭 호환.
- [마케팅몰 stub] shop/index.html(오픈예정 랜딩+입점 예정 상품 미리보기, ?tab=cart/orders/point/market 안내). **매칭·마케팅몰 상세는 2단계 예정.**
- [검증] 5731. 콘솔 0. 내부 링크 35개 전수 200(깨진 링크 0). 계산기 동작 확인(참여율 4.42%·ROAS 300%·해시태그 21개·블로그 지수/키워드 정상 — 부호 있는 시프트 버그 `>>`→`>>>` 수정). 반응형 375/768 가로 스크롤 0. 헤더 배지·유틸바·10분류 렌더 확인.

### ▷ 2단계(예정) — 매칭·마케팅몰 상세
- 매칭: matching 홈(인플루언서/광고주/대행사 매칭 흐름), 인플루언서 찾기·등록, 광고주 요청, 광고 의뢰. (현재는 directory/projects로 연결만)
- 마케팅몰: 상품 목록/상세/장바구니/주문/포인트 실제 UI. (현재 오픈예정 stub)
- 더보기 탭(마케팅 캘린더·배지·친구추천·쪽지) 콘텐츠 보강, 콘텐츠(insights) 카테고리 라벨 marketslab형(가이드/용어사전/뉴스·트렌드/성공사례) 정합.

## ▶ 진행 로그 (2026-07-21 · 방향 정정 — 언론홍보 커뮤니티+매거진)
> **정체성 확정(사용자)**: PRCOME = 종합 마케팅 플랫폼 ✕ → **‘언론홍보 업계 종사자를 위한 커뮤니티 + 전문 매거진’**. PR 70 : 마케팅 30. PR회사·언론사·구인구직·홍보대행·도서·교육은 **커뮤니티·매거진을 지원하는 업계 정보 기능**(핵심 서비스로 크게 강조 ✕). marketslab는 아이콘 가시성·정보정렬·섹션구분만 참고(기능형 마케팅몰/서비스판매 사이트 ✕). **5초 안에 ‘언론홍보 사람들이 글 나누고 전문 콘텐츠 읽는 곳’으로 인지**되게.
> → 직전 marketslab 복제 버전(유틸바·게이미피케이션·10분류·마케팅몰/체험단/도구 강조)을 **헤더·홈·커뮤니티에서 롤백**. (계산기·experience·shop 파일은 삭제 안 함 — 계산기는 더보기›PR 실무 도구(tools/index)로 접근 유지, experience/shop은 미연결 보존.)
- [헤더] magazine-header.js 재작성: **유틸바 제거**. 메뉴 우선순위 = 커뮤니티·인사이트·PR회사·언론사·구인구직·홍보대행 의뢰·도서·교육 + 더보기(PR도구·행사·공지·이용안내·문의). PR회사=directory/agencies, 언론사=directory/media 분리(act substring으로 활성 구분). 아이콘 최소(텍스트 위주). 검색=커뮤니티+매거진 통합.
- [홈] index.html **7섹션 우선순위 재구성**: ①히어로(차분한 에디토리얼: "언론홍보 실무자들이/정보와 경험을 나누는 곳"+설명+통합검색+절제 통계) ②**커뮤니티(최대 비중)**=탭(인기글/최신글/질문·답변/실무자료) 피드[제목·카테고리·작성자·시간·조회·댓글]+우측(인기 주제·활발한 작성자) ③PR 매거진=대표1(포스터+카테고리+요약+출처·발행일)+최신4, 카테고리(언론홍보전략/보도자료/기자커뮤니케이션/위기관리/성공사례) ④업계 정보=추천 PR회사+언론사(로고·분야·지역·특징 간결) ⑤업계 기회(낮은 비중·촘촘)=최신 채용+홍보대행 의뢰 ⑥PR 자료=도서+교육 작은 카드 ⑦가입 유도(커뮤니티 참여 문구). **서비스 6개 바로가기는 히어로 아래 얇은 보조 탐색 스트립으로 축소**. 마케팅 게이미피케이션(출석·행운·활동왕·LIVE·1만P) 제거. 이모지 헤더 제거→.klab 텍스트 라벨.
- [커뮤니티] 카테고리 PR 세트로 복구: 전체 피드/질문·답변/업계 소식/실무 노하우/언론홍보 사례/자유게시판/구인구직/홍보대행 의뢰. 로켓펀치 3분할 레이아웃 유지. 구 marketslab 링크(promo·info·press·intro 등) 별칭 호환.
- [검증] 5731. 콘솔 0, 홈 내부 링크 18 전수 200(깨진 링크 0), 반응형 360/375/768 가로 스크롤 0. 헤더 7메뉴·유틸바 제거·섹션 순서(커뮤니티→매거진→업계정보→업계기회→PR자료) 확인. 커뮤니티 탭·카테고리·별칭 동작 확인. (스크린샷 툴은 환경 타임아웃 → DOM/snapshot 검증)

## ▶ 진행 로그 (2026-07-21 · 헤더 정렬·아이콘 + 언론사 리스트)
- [헤더] 상단 메뉴·보조탐색 스트립 **가운데 정렬**(.hd .r2 .in / .quicknav .in justify-content:center). 8개 대분류 + 보조탐색 6개에 **구분용 라인 아이콘**(currentColor SVG, 흐린회색→hover/active 파랑). magazine-header.js에 IC 세트+.nic 렌더(데스크톱·모바일 아코디언), magazine-system.css에 .nic 스타일. 아이콘은 메뉴/보조탐색에만(본문 카드 X).
- [언론사 페이지] directory/media.html → **「대한민국 언론사 리스트」 종합 레퍼런스**(akj.or.kr형 카테고리 칩 디렉토리)로 재구성. 5섹션: ①네이버 등록 언론사(newsstand.naver.com) ②다음뉴스 제휴 채널(news.daum.net/cplist) ③언론기관·단체(akj.or.kr/agency — **WebFetch 실측**: 정부유관기관·방송사·통신사·신문(중앙일간/경제/시사/스포츠/전문/영자)·온라인·언론단체) ④언론교육기관(akj/academy) ⑤언론관련학과(akj/univ-department). 총 314개 항목, 카테고리별 그룹 라벨+칩 그리드, **검색 필터**(하이라이트·빈 그룹/섹션 자동 숨김), **sticky 앵커 서브내비**(스크롤 활성표시), 각 섹션 출처 링크. akj academy/univ는 WebFetch 529 과부하로 미확보 → 공개 자료 기반 대표기관 큐레이션(1차 참고, 출처 링크 명시). 반응형 칩 5/3/2열. 콘솔0.

## ▶ 진행 로그 (2026-07-21 · 도서 실데이터)
- [도서] resources/books.html → **한국PR협회 PR도서(koreapr.org/library_book) 실데이터 10종**으로 교체. 원본이 imweb SPA라 WebFetch(529) 대신 **PowerShell로 raw HTML 수집→정규식 파싱**으로 제목·저자·표지이미지(cdn.imweb.me)·상세 idx 추출. 세로 표지 카드 그리드(표지 실이미지 로드 확인, onerror 시 제목 플레이스홀더), 분류 탭(PR 이론·용어/AI·트렌드/커뮤니케이션/전략·ESG/위기·사례) + 카운트, 각 책→koreapr 상세(bmode=view&idx=) 새 탭. 출처·저작권 고지(한국PR협회/각 출판사). 교육기관 섹션 유지. 반응형 5/4/3/2열, 표지 10/10 로드, 콘솔0. (임시파일 _krpr_books.html 생성 후 삭제)

## ▶ 진행 로그 (2026-07-21 · 홈 메뉴·PR뉴스·AI데모·도서표지)
- [헤더] **홈 메뉴 추가**(최좌측, 홈 아이콘, 루트에서 활성). magazine-header.js NAV 첫 항목 + navActive home 분기.
- [홈] 히어로 통계 **‘실무자 294명’ → ‘회원 294명’**. **PR 업계 뉴스 섹션 추가**(한국PR협회 뉴스룸 newsroom-prnews 실데이터 6건: 더피알·브랜드브리프·AP신문·매드타임스 주간 뉴스스크랩, 소스 태그+상세 새탭). **AI 워크스페이스 밴드 복원**(네이비 밴드, 보도자료 작성 AI→tools/pr-agent/index.html?start=write, 배포 AI→?start=distribute — AI 데모 파일 직결). 반응형 뉴스 1열·밴드 세로.
- [도서 표지 수정] 외부 imweb 표지가 **핫링크 차단**으로 안 뜨던 문제 → **표지 10종 로컬 저장**(assets/img/books/book-<idx>.<ext>, PowerShell 다운로드) 후 로컬 경로 참조. 표지 10/10 로드 확인. .ph 플레이스홀더 inset:0+overflow:hidden으로 넘침 방지(로드 실패 시 폴백).
- [검증] 콘솔0, AI데모 200, 도서표지 로컬 10/10, 뉴스 6건, 홈 활성, 회원 라벨, 360/768 오버플로0. 임시파일(_krpr_news/_krpr_books) 삭제.

## ▶ 진행 로그 (2026-07-21 · 표지·뉴스썸네일 수정)
- [도서 표지 근본원인 수정] resources/books.html `.cover`가 `<span>`(inline)→너비 0으로 계산돼 이미지 0px 렌더(안 보임). **display:block + padding-top:133.33%(비율 하드코딩)**으로 교체 → 209×279 정상 렌더, 표지 10/10 표시.
- [홈 PR자료 도서] 빈 남색 플레이스홀더 → **실제 표지 3종**(디지털 시대의 PR 용어 300·AI와 PR회사에서 일하기·블랙스완 시대의 PR) 이미지 삽입(.book .cv img). 3/3 표시.
- [홈 PR뉴스 썸네일] 소스 로고 4종(더피알·브랜드브리프·AP신문·매드타임스) **로컬 저장**(assets/img/news/) 후 뉴스 카드에 썸네일+제목+소스·뉴스룸 정보. **각 카드 클릭 → 한국PR협회 뉴스룸 해당 글(newsroom-prnews/?bmode=view&idx=) 새 탭**. 6/6 표시.
- [핵심 교훈] 표지/썸네일 박스는 inline `<span>` 금지·padding-top 비율 사용(aspect-ratio 미지원/inline 붕괴 방지). 외부 imweb 이미지는 핫링크 차단→반드시 로컬 저장.
- [미완] **외부 공유 링크**: 사용자 요청('외부에 링크로 공유'). 환경=cloudflared/ngrok 없음, winget/git/node/npx 있음. 방식(임시 터널 vs 정적 배포) 미결정 → 다음 턴.

## ▶ 진행 로그 (2026-07-21 · 뉴스 상단 이동·확대)
- [홈 순서] PR 업계 뉴스를 **메인 배너 바로 아래(quicknav 다음, 커뮤니티 위)** 로 이동. 섹션 순서: 뉴스 → 커뮤니티 → 매거진 → 업계정보 → 업계기회 → PR자료. (뉴스가 첫 콘텐츠, 히어로 하단 51px)
- [뉴스 확대] 카드 대형화(썸네일 66→**92px**, 제목 14.5→**17px**, 카드높이 ~130px, hover 리프트, **‘원문 보기 ↗’** 큐 추가). 헤딩 ‘지금 PR 업계에서는 — 한국PR협회 뉴스룸’. 반응형 1280 2열 / 768·360 1열. 썸네일 6/6 로드. 각 카드 클릭→koreapr 뉴스룸 원문 새탭.

## ▶ 진행 로그 (2026-07-21 · pr-agent 헤더 통일 + AI데모 배너 노출)
- [pr-agent 디자인 통일] tools/pr-agent/index.html이 **옛 site.js 헤더**(#site-header, 초록로고·구 내비)를 써서 이질적이었음 → **공통 magazine-header.js로 교체**: magazine-system.css 링크 추가(인라인 <style> 앞이라 pr-agent 자체 .btn/.card/토큰은 인라인이 우선=엔진 UI 보존), window.MAG 주입, #site-header→#mag-header, site.js→magazine-header.js, favicon 통일. 검증: 공통 9메뉴 헤더 표시, 7단계 진행·입력패널·엔진 정상, primary 버튼색 #315CFF 유지, 콘솔0. **엔진/생성기/config.js/?start 파라미터 무수정.**
- [AI데모 배너 노출] 홈 히어로에 **네이비 알약 CTA '✨ 보도자료를 AI로 작성·배포하기 [AI 워크스페이스] →'**(→ pr-agent?start=write) 추가. 배너 내부 노출·반응형 오버플로0. (하단 AI 워크스페이스 밴드는 유지)

## 진행 순서 (사용자 지정)
1 agencies(목록+상세=directory/detail) ✅ → 2 media ✅ → 3 projects ✅(index/new/detail) → **4 career(다음)** → 5 tools → 6 도서/교육기관 → 7 community post/write → 8 auth/legal/help/notice

## 보호 (수정 금지)
원본 PRCOME · backend · Render/Resend/CORS · pr-agent 엔진/화면 로직 · AI `?start=write|distribute` 파라미터 · 기존 링크/JS 기능 · 파일 삭제 금지.

## 대표 확인 URL
http://localhost:5731/index.html · /insights/index.html?cat=pr · /directory/index.html · /directory/agencies.html · /directory/media.html · /projects/index.html · /career/index.html · /tools/index.html
