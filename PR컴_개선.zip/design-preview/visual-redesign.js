/* PRCOME Visual Redesign — 차분한 모션 (prefers-reduced-motion 지원) */
(function(){
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion:reduce)').matches;

  /* LIVE 브리핑 실제 시각 */
  var d=new Date(), pad=function(n){return('0'+n).slice(-2);};
  var bt=document.getElementById('briefTime');
  if(bt) bt.textContent='업데이트 '+pad(d.getHours())+':'+pad(d.getMinutes());

  var lns=[].slice.call(document.querySelectorAll('.hero-l .ln'));
  var ups=[].slice.call(document.querySelectorAll('.up'));

  if(reduce || !('IntersectionObserver' in window)){
    lns.concat(ups).forEach(function(el){ el.classList.add('in'); });
    return;
  }

  /* 제목: 줄 단위 순차 등장 */
  lns.forEach(function(el,i){ setTimeout(function(){ el.classList.add('in'); }, 120 + i*130); });

  /* 스크롤 진입: 20px 이동하며 등장 (문서순 짧은 스태거) */
  var io=new IntersectionObserver(function(entries){
    var hit=entries.filter(function(e){return e.isIntersecting;})
                   .map(function(e){return e.target;})
                   .sort(function(a,b){return ups.indexOf(a)-ups.indexOf(b);});
    hit.forEach(function(el,i){ setTimeout(function(){ el.classList.add('in'); }, Math.min(i,5)*80); io.unobserve(el); });
  },{threshold:0.14, rootMargin:'0px 0px -8% 0px'});
  ups.forEach(function(el){ io.observe(el); });

  /* 배너 컴포지션: 스크롤에 따른 아주 미세한 이동(최대 10px) */
  var compo=document.getElementById('compo');
  var cards=compo && compo.querySelector('.cards');
  if(cards){
    var ticking=false;
    window.addEventListener('scroll', function(){
      if(ticking) return; ticking=true;
      requestAnimationFrame(function(){
        var r=compo.getBoundingClientRect();
        var vh=window.innerHeight||800;
        if(r.bottom>0 && r.top<vh){
          var prog=(vh - r.top)/(vh + r.height); // 0~1
          var y=(0.5 - Math.max(0,Math.min(1,prog))) * 20; // -10 ~ +10px
          cards.style.transform='translateY('+y.toFixed(1)+'px)';
        }
        ticking=false;
      });
    }, {passive:true});
  }
})();
