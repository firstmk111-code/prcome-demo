/* 기사 상세 — 진입 모션 / 공유 / 광고성 표시(advertorial일 때만) */
(function(){
  var p=new URLSearchParams(location.search);

  /* 콘텐츠 유형이 advertorial 일 때만 제목 근처에 명확히 표시 */
  var type=(p.get('type')||'').toLowerCase();
  var AD={advertorial:'애드버토리얼 · 광고',sponsored:'스폰서 콘텐츠',ad:'광고'};
  if(AD[type]){
    var b=document.getElementById('adBadge'), t=document.getElementById('adText');
    if(b){ if(t) t.textContent=AD[type]; b.classList.add('show'); }
  }

  /* 공유(링크 복사) */
  var sc=document.getElementById('shareCopy');
  if(sc) sc.addEventListener('click',function(){
    var url=location.href;
    if(navigator.clipboard){navigator.clipboard.writeText(url).then(function(){sc.textContent='복사됨';setTimeout(function(){sc.textContent='링크';},1500);});}
    else alert('링크: '+url);
  });

  /* 진입 모션 */
  var reduce=window.matchMedia&&window.matchMedia('(prefers-reduced-motion:reduce)').matches;
  var ups=[].slice.call(document.querySelectorAll('.up'));
  if(reduce||!('IntersectionObserver'in window)){ups.forEach(function(e){e.classList.add('in');});return;}
  var io=new IntersectionObserver(function(es){es.filter(function(e){return e.isIntersecting;}).forEach(function(e,i){setTimeout(function(){e.target.classList.add('in');},Math.min(i,4)*80);io.unobserve(e.target);});},{threshold:.1,rootMargin:'0px 0px -6% 0px'});
  ups.forEach(function(e){io.observe(e);});
})();
