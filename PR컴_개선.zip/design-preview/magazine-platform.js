/* PRCOME Magazine Platform — 차분한 편집 모션 (prefers-reduced-motion 지원) */
(function(){
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion:reduce)').matches;
  var ups = [].slice.call(document.querySelectorAll('.up'));

  if(reduce || !('IntersectionObserver' in window)){
    ups.forEach(function(el){ el.classList.add('in'); });
    return;
  }

  /* 섹션 진입: 제목·콘텐츠 순차 표시 */
  var io = new IntersectionObserver(function(entries){
    var hit = entries.filter(function(e){return e.isIntersecting;})
                     .map(function(e){return e.target;})
                     .sort(function(a,b){return ups.indexOf(a)-ups.indexOf(b);});
    hit.forEach(function(el,i){ setTimeout(function(){ el.classList.add('in'); }, Math.min(i,5)*90); io.unobserve(el); });
  }, { threshold:0.12, rootMargin:'0px 0px -8% 0px' });
  ups.forEach(function(el){ io.observe(el); });

  /* 대표 기사 이미지: 스크롤 시 아주 미세한 이동 (최대 ~12px) */
  var img = document.getElementById('leadImg');
  if(img){
    var ticking=false;
    window.addEventListener('scroll', function(){
      if(ticking) return; ticking=true;
      requestAnimationFrame(function(){
        var r=img.getBoundingClientRect(), vh=window.innerHeight||800;
        if(r.bottom>0 && r.top<vh){
          var prog=(vh - r.top)/(vh + r.height);
          var y=(0.5 - Math.max(0,Math.min(1,prog))) * 24; // -12 ~ +12px
          img.style.backgroundPositionY = (50 + y*0.4).toFixed(1)+'%';
          img.style.transform = 'translateY('+(y*0.25).toFixed(1)+'px)';
        }
        ticking=false;
      });
    }, {passive:true});
  }
})();
