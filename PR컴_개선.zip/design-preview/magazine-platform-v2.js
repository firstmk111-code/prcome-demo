/* PRCOME Magazine Platform v2 — 진입 모션 + 모바일 메뉴 (prefers-reduced-motion 지원) */
(function(){
  /* 모바일 메뉴 토글 */
  var mbtn=document.getElementById('mbtn'), mpanel=document.getElementById('mpanel');
  if(mbtn && mpanel){ mbtn.addEventListener('click', function(){ mpanel.classList.toggle('open'); }); }

  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion:reduce)').matches;
  var ups = [].slice.call(document.querySelectorAll('.up'));
  if(reduce || !('IntersectionObserver' in window)){
    ups.forEach(function(el){ el.classList.add('in'); });
    return;
  }
  var io = new IntersectionObserver(function(entries){
    var hit = entries.filter(function(e){return e.isIntersecting;})
                     .map(function(e){return e.target;})
                     .sort(function(a,b){return ups.indexOf(a)-ups.indexOf(b);});
    hit.forEach(function(el,i){ setTimeout(function(){ el.classList.add('in'); }, Math.min(i,5)*90); io.unobserve(el); });
  }, { threshold:0.12, rootMargin:'0px 0px -8% 0px' });
  ups.forEach(function(el){ io.observe(el); });
})();
