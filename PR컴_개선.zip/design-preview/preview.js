/* PRCOME 시안 공통 모션/유틸 — 가벼운 진입 노출 + 실시간 날짜·시각 */
(function(){
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion:reduce)').matches;

  /* 날짜/시각 (실제값) */
  function pad(n){ return ('0'+n).slice(-2); }
  var W=['일','월','화','수','목','금','토'];
  var WE=['SUN','MON','TUE','WED','THU','FRI','SAT'];
  var ME=['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'];
  function stamp(){
    var d=new Date();
    document.querySelectorAll('[data-date]').forEach(function(el){
      el.textContent = WE[d.getDay()]+' '+pad(d.getDate())+' '+ME[d.getMonth()]+' '+d.getFullYear();
    });
    document.querySelectorAll('[data-clock]').forEach(function(el){
      el.textContent = (d.getMonth()+1)+'월 '+d.getDate()+'일('+W[d.getDay()]+') '+pad(d.getHours())+':'+pad(d.getMinutes());
    });
  }
  stamp();

  /* 진입 노출 (순차) */
  var items = [].slice.call(document.querySelectorAll('.reveal'));
  if(reduce || !('IntersectionObserver' in window)){
    items.forEach(function(el){ el.classList.add('is-in'); });
    return;
  }
  var io = new IntersectionObserver(function(entries){
    // 화면에 들어온 요소를 문서 순서대로 짧게 스태거
    var hit = entries.filter(function(e){ return e.isIntersecting; })
                     .map(function(e){ return e.target; })
                     .sort(function(a,b){ return items.indexOf(a)-items.indexOf(b); });
    hit.forEach(function(el,i){
      var delay = Math.min(i,6)*70;
      setTimeout(function(){ el.classList.add('is-in'); }, delay);
      io.unobserve(el);
    });
  }, { threshold:0.12, rootMargin:'0px 0px -8% 0px' });
  items.forEach(function(el){ io.observe(el); });
})();
