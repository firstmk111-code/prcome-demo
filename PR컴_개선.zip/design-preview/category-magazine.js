/* 인사이트 카테고리 — URL ?cat 에 따라 제목·설명·활성·콘텐츠 동적 표시 */
(function(){
  var ART = 'article-magazine.html';
  var CAT = {
    all:{name:'인사이트', kw:'INSIGHT', desc:'PR·언론·마케팅 실무의 오늘을 편집팀이 정리합니다.',
      sub:['전체','PR','마케팅','SEO·GEO','칼럼'],
      feat:['AI가 보도자료를 읽는 시대, 기업 PR은 무엇을 준비해야 하나','생성형 AI가 보도자료를 요약·인용하기 시작하면서 홍보실의 문장 하나가 검색과 AI 답변으로 확산된다.'],
      arts:['애드버토리얼은 어디까지 광고로 표시해야 할까','검색에서 답변으로, GEO가 바꾸는 기업 홍보','기자가 실제로 읽는 보도자료의 첫 문장','브랜드 위기 대응, 최초 30분이 중요한 이유','오너드미디어, 뉴스룸을 콘텐츠 채널로','측정할 수 없다면 홍보가 아니다','우리 브랜드가 챗봇 답변에 안 나오는 이유','참여형 캠페인이 다시 주목받는 이유','채택되는 보도자료의 제목은 무엇이 다른가','소비자 트렌드로 읽는 2026 브랜드 언어']},
    pr:{name:'PR', kw:'PR', desc:'미디어 관계, 보도자료, 위기관리와 기업 커뮤니케이션을 다룹니다.',
      sub:['전체','보도자료','미디어 릴레이션','위기관리','기업 커뮤니케이션'],
      feat:['브랜드 위기, 최초 30분에 결정되는 신뢰 회복의 조건','사건 발생 후 첫 대응은 사실 확인·창구 단일화·메시지 정렬로 압축된다. 실무자가 점검할 순서를 사례와 함께 정리했다.'],
      arts:['채택되는 보도자료의 제목은 무엇이 다른가','기자와의 관계는 배포가 아니라 신뢰에서 시작된다','보도자료 배포 후 기사화 가능성을 높이는 5가지 방법','사내 메시지와 대외 메시지, 어떻게 정렬할까','대표님의 ‘신문에 나오게 해줘’를 번역하는 법','위기 상황, 홍보실이 가장 먼저 해야 할 일','보도자료 첫 문장에서 승부가 갈린다','언론 배포 리스트, 넓히기보다 좁혀라','기업 메시지 하우스, 어떻게 설계할까','기고와 인터뷰, 언제 무엇을 택할까']},
    marketing:{name:'마케팅', kw:'MKT', desc:'브랜드, 콘텐츠, 광고와 변화하는 소비자 접점을 분석합니다.',
      sub:['전체','브랜드','콘텐츠','광고','디지털 캠페인','소비자 트렌드'],
      feat:['짧아진 주목, 3초 안에 브랜드를 각인시키는 법','스크롤 속도가 빨라진 시대, 첫 3초가 캠페인의 성패를 가른다. 주목을 붙잡는 구조를 사례로 살폈다.'],
      arts:['참여형 캠페인이 다시 주목받는 이유','오너드미디어, 뉴스룸을 콘텐츠 채널로','소비자 트렌드로 읽는 2026 브랜드 언어','퍼포먼스와 브랜딩, 예산은 어떻게 나눌까','콘텐츠 캘린더를 성과로 연결하는 법','브랜드 보이스, 말투가 신뢰가 되기까지','리텐션을 만드는 콘텐츠의 조건','데이터로 증명하는 마케팅 리포트','인플루언서 협업, 무엇을 계약서에 담을까','캠페인 이후, 자산으로 남기는 법']},
    brand:{name:'브랜드·콘텐츠', kw:'BRAND', desc:'브랜드 아이덴티티와 오너드미디어 콘텐츠 전략을 다룹니다.',
      sub:['전체','브랜딩','콘텐츠','오너드미디어','네이밍'],
      feat:['브랜드의 말투는 어떻게 신뢰가 되는가','시각 아이덴티티만큼 중요한 언어 아이덴티티. 브랜드 보이스를 설계하고 유지하는 방법을 정리했다.'],
      arts:['오너드미디어, 뉴스룸을 콘텐츠 채널로','네이밍, 검색과 상표를 함께 고려하기','브랜드 스토리를 기사로 옮기는 법','콘텐츠 허브 전략의 기본','비주얼과 카피의 균형 잡기','브랜드 가이드, 실무에서 살아남게 하기','리브랜딩, 언제가 적기인가','시리즈 콘텐츠로 팬을 만드는 법','브랜드 저널리즘의 경계','톤앤매너를 문서화하는 방법']},
    media:{name:'미디어', kw:'MEDIA', desc:'언론 환경과 매체 전략, 기자 관계의 변화를 다룹니다.',
      sub:['전체','언론 환경','매체 전략','기자 관계'],
      feat:['기자의 메일함에서 살아남는 보도자료','하루 수백 통의 메일 속에서 열리는 제목과 리드는 무엇이 다른가. 전 경제지 기자의 관점을 들었다.'],
      arts:['산업별 전문지 담당 부서, 어떻게 파악할까','매체 성격에 맞춰 아이템을 다듬는 법','온라인·지면 배포, 무엇이 다른가','통신사 전재의 구조 이해하기','기자 컨택, 첫 메일의 원칙','엠바고와 단독, 실무 매너','매체 리스트를 정기적으로 갱신하는 법','전문지와 종합지, 접근을 달리하라','보도 모니터링을 리포트로','미디어 데이 준비 체크리스트']},
    digital:{name:'디지털', kw:'DIGITAL', desc:'퍼포먼스, 채널, 그로스와 데이터 기반 마케팅을 다룹니다.',
      sub:['전체','퍼포먼스','채널','그로스','데이터'],
      feat:['측정할 수 없다면 홍보가 아니다','노출과 클릭을 넘어, 홍보가 만든 변화를 어떻게 지표로 증명할 것인가. 실무 측정 프레임을 제안한다.'],
      arts:['채널별 역할을 나누는 통합 플래닝','리드젠, 트래픽보다 전환이 먼저다','UTM과 리포트 설계의 기본','그로스 실험을 조직에 심는 법','랜딩페이지 카피의 원칙','데이터 대시보드, 무엇을 볼 것인가','검색 유입을 문의로 잇는 구조','리마케팅의 적정선','콘텐츠 성과를 코호트로 보기','예산 배분을 데이터로 방어하기']},
    seo:{name:'SEO', kw:'SEO', desc:'검색엔진 최적화의 기초와 기술 실무를 다룹니다.',
      sub:['전체','키워드','콘텐츠','기술 SEO'],
      feat:['B2B 홈페이지 SEO, 트래픽보다 리드가 먼저다','검색 유입을 실제 문의로 전환하는 B2B 콘텐츠 구조와 기술 SEO의 우선순위를 정리했다.'],
      arts:['키워드 리서치, 의도로 분류하기','타이틀·메타 설명 최적화의 기본','내부 링크로 문맥을 만드는 법','구조화 데이터 시작하기','속도와 모바일, 무엇부터','콘텐츠 클러스터 설계','검색 콘솔로 문제 찾기','중복 콘텐츠 정리하기','이미지 SEO의 기초','SEO와 홍보의 접점']},
    geo:{name:'AEO·GEO', kw:'GEO', desc:'답변엔진과 생성형 검색에서의 브랜드 가시성을 다룹니다.',
      sub:['전체','AEO','GEO','AI 인용','사례'],
      feat:['검색이 답변이 되는 시대, 무엇을 최적화할 것인가','키워드 상위 노출을 넘어, AI가 우리 브랜드를 정확히 인용하도록 만드는 일이 과제가 됐다. SEO·AEO·GEO의 차이를 해설한다.'],
      arts:['AI가 인용하는 콘텐츠 구조 만들기','챗봇 답변에 인용된 브랜드의 공통점','FAQ·요약 문단으로 스니펫 잡기','회사 정보 정합성이 인용을 만든다','GEO 준비 체크리스트','언론 노출과 AI 인용의 관계','구조화 데이터와 답변 엔진','우리 브랜드 가시성 진단하기','생성형 검색 시대의 위기','AI 검색 사례 3선']},
    'ai-pr':{name:'AI와 PR', kw:'AI·PR', desc:'생성형 AI가 바꾸는 홍보 실무와 워크플로를 다룹니다.',
      sub:['전체','AI 작성','AI 배포','AI 검색','윤리'],
      feat:['AI가 보도자료를 읽는 시대, 기업 PR은 무엇을 준비해야 하나','생성형 AI가 보도자료를 요약·인용하기 시작하면서, 홍보실의 문장 하나가 검색과 AI 답변으로 확산된다.'],
      arts:['보도자료 작성 AI, 어디까지 맡길까','매체 매칭 AI로 배포 리스트 좁히기','AI 초안을 검토하는 실무 원칙','생성형 AI 시대의 사실 정합성','AI가 만든 콘텐츠의 표기 문제','홍보팀 워크플로에 AI 심기','프롬프트보다 데이터가 먼저다','AI 검색 가시성 관리의 기본','AI 오인용, 어떻게 대응할까','사람이 남겨야 할 판단']},
    column:{name:'칼럼·인터뷰', kw:'COLUMN', desc:'현장 실무자의 칼럼과 인물 인터뷰를 싣습니다.',
      sub:['전체','칼럼','인터뷰'],
      feat:['“보도자료는 팩트, 스토리는 관계에서 나온다”','채택되는 보도자료의 공통점부터 기자와의 신뢰를 쌓는 법까지, 현직 산업부 데스크(익명)의 이야기를 들었다.'],
      arts:['대표님의 ‘신문에 나오게 해줘’를 번역하는 법','기자의 메일함에서 살아남는 보도자료','측정할 수 없다면 홍보가 아니다','브랜드의 말투는 어떻게 신뢰가 되는가','인하우스와 대행사, 무엇이 다른가','20년차 PR 실무자의 하루','전 기자가 말하는 좋은 홍보','그로스 리드의 홍보 관점','위기관리 컨설턴트의 노트','편집장의 서문']}
  };

  function pad(n){return('0'+n).slice(-2);}
  function fdate(off){var d=new Date();d.setDate(d.getDate()-off);return d.getFullYear()+'.'+pad(d.getMonth()+1)+'.'+pad(d.getDate());}
  function pick(arr,i){return arr[i%arr.length];}
  function rt(i){return (5+((i*3)%6))+'분 읽기';}

  var params=new URLSearchParams(location.search);
  var key=params.get('cat'); if(!key || !CAT[key]) key = key ? key : 'all';
  if(!CAT[key]) key='all';
  var d=CAT[key];

  document.body.className = 'acc-'+(key==='all'?'pr':key);
  document.title = d.name+' — PRCOME';
  document.getElementById('cCrumb').textContent=d.name;
  document.getElementById('cName').textContent=d.name;
  document.getElementById('cDesc').textContent=d.desc;
  document.getElementById('cMeta').textContent='PRCOME 편집팀 편집 · 최근 업데이트 '+fdate(0);

  /* 하위 주제 텍스트 탭 (활성=밑줄) */
  document.getElementById('subtabs').innerHTML = d.sub.map(function(s,i){
    return '<button role="tab" class="'+(i===0?'on':'')+'"'+(i===0?' aria-selected="true"':'')+'>'+s+'</button>';
  }).join('');
  document.querySelectorAll('#subtabs button').forEach(function(b){
    b.addEventListener('click',function(){
      document.querySelectorAll('#subtabs button').forEach(function(x){x.classList.remove('on');x.removeAttribute('aria-selected');});
      b.classList.add('on'); b.setAttribute('aria-selected','true');
    });
  });

  /* 대표 기사 */
  document.getElementById('cfeat').innerHTML =
    '<a href="'+ART+'"><div class="imgwrap r169"><div class="poster-g">'+
      '<span class="accbar"></span><span class="lab">'+d.name+' <i>·</i> PRCOME</span><div class="blue"></div>'+
      '<span class="tick t1"></span><span class="tick t2"></span><span class="tick t3"></span>'+
      '<div class="big">'+d.kw+'</div><span class="rule"></span><span class="sub">PR · MEDIA · SEARCH</span>'+
    '</div></div></a>'+
    '<span class="cat">'+d.name+'</span>'+
    '<a href="'+ART+'"><h2 class="h">'+d.feat[0]+'</h2></a>'+
    '<p class="sum">'+d.feat[1]+'</p>'+
    '<div class="byline"><span>PRCOME 편집팀</span><span class="d"></span><span>'+fdate(1)+'</span><span class="d"></span><span>'+rt(3)+'</span></div>';

  /* 최신 기사 4 */
  document.getElementById('clatest').innerHTML =
    '<div class="lh">최신 기사</div>'+
    d.arts.slice(0,4).map(function(t,i){
      return '<a href="'+ART+'"><h4 class="h">'+t+'</h4><div class="m">'+fdate(i+1)+' · '+rt(i+2)+'</div></a>';
    }).join('');

  /* 기사 목록 6 (이미지형 3 + 텍스트형 3) */
  var imgs = d.arts.slice(4,7).map(function(t,i){
    return '<a class="a-img" href="'+ART+'"><div class="mini-poster"><span class="bar"></span><span class="pt">'+d.name+'</span><span class="k">'+d.kw+'</span></div>'+
      '<span class="cat">'+d.name+'</span><h4 class="h">'+t+'</h4><div class="m">'+fdate(i+3)+' · '+rt(i+1)+'</div></a>';
  }).join('');
  var txts = '<div class="txtwrap">'+ d.arts.slice(7,10).map(function(t,i){
    return '<a class="a-txt" href="'+ART+'"><span class="cat">'+d.name+'</span><h4 class="h">'+t+'</h4><span class="m">'+fdate(i+6)+' · '+rt(i+4)+'</span></a>';
  }).join('') + '</div>';
  document.getElementById('clist').innerHTML = imgs + txts;

  /* 편집팀 추천 1~5 (조회 데이터 없음 → '주목할 콘텐츠') */
  document.getElementById('cpicks').innerHTML =
    '<div class="ph">편집팀 추천 · 주목할 콘텐츠</div>'+
    [d.feat[0]].concat(d.arts.slice(0,4)).map(function(t,i){
      return '<a href="'+ART+'"><span class="n">'+(i+1)+'</span><span class="t h">'+t+'</span></a>';
    }).join('');

  /* 진입 모션 */
  var reduce=window.matchMedia&&window.matchMedia('(prefers-reduced-motion:reduce)').matches;
  var ups=[].slice.call(document.querySelectorAll('.up'));
  if(reduce||!('IntersectionObserver'in window)){ups.forEach(function(e){e.classList.add('in');});return;}
  var io=new IntersectionObserver(function(es){es.filter(function(e){return e.isIntersecting;}).forEach(function(e,i){setTimeout(function(){e.target.classList.add('in');},Math.min(i,4)*80);io.unobserve(e.target);});},{threshold:.1,rootMargin:'0px 0px -6% 0px'});
  ups.forEach(function(e){io.observe(e);});
})();
